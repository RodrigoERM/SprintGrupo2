package controlador;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import implementacion.UsuarioImpl;
import interfaces.IUsuario;
import modelo.Usuario;

@WebServlet("/ListarUsuarios")
public class ListarUsuarios extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        IUsuario usuarioDao = new UsuarioImpl();  // Implementación de la interfaz de usuario
        List<Usuario> usuarios = usuarioDao.listarUsuarios();  // Obtener la lista de usuarios

        // Enviar la lista de usuarios al JSP
        request.setAttribute("usuarios", usuarios);
        getServletContext().getRequestDispatcher("/views/listarusuarios.jsp").forward(request, response);
    }
}
