package implementacion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import conexion.Conexion;
import interfaces.IProfesional;
import modelo.Profesional;

public class ProfesionalImpl implements IProfesional{
	
	@Override
    public List<Profesional> listarProfesionales() {
        List<Profesional> profesionales = new ArrayList<>();
        Connection conn = null;
        String sql = "SELECT * FROM profesional";
        
        try {
            conn = Conexion.getConnection();
            try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                	Profesional profesional = new Profesional();
                	
                    profesional.setTitulo(rs.getString("titulo"));
                    profesional.setFechaIngreso(rs.getString("fecha_ingreso"));
                    profesionales.add(profesional);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
        }
        return profesionales;
	}
	
	 @Override
	    public void registrarProfesional(Profesional profesional) {
	        Connection conn = null;
	        String sql = "INSERT INTO profesional (titulo, fecha_ingreso) VALUES (?, ?)";
	        
	        try {
	            conn = Conexion.getConnection();
	            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
	                pstmt.setString(1, profesional.getTitulo());
	                pstmt.setString(2, profesional.getFechaIngreso());
	                pstmt.executeUpdate();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        } finally {
	        
	        }
	 }
}
