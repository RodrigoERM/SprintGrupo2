package interfaces;

import java.util.List;

import modelo.Profesional;

public interface IProfesional {
		List<Profesional> listarProfesionales();
	    void registrarProfesional(Profesional profesional);
}
